# Karachi Bus Routes — Primary KML Audit

## Source and processing rules

- Source file: `Think Transportation - Red Bus (Peoples Bus Service) Routes Karachi (1).kml`
- KML document: **Think Transportation - Red Bus (Peoples Bus Service) Routes Karachi**
- Source description date: **1 February 2025**
- Primary route geometry: this KML, exactly as supplied.
- Processing: parsed each KML `LineString`; preserved every coordinate and its original order; calculated approximate geodesic polyline length and nearest-line comparisons.
- No route geometry was edited, snapped, reordered, simplified, or replaced.
- No MySQL records were changed and no records were approved.
- The KML contains route lines, not separate named stop placemarks. Stop positions below are comparisons against existing coordinate candidates, not new stop assignments.

## Inventory

- Route LineStrings: **15**
- Coordinate vertices: **10,803**
- Combined approximate line length: **463.52 km**
- Red Bus routes: **10**
- EV routes: **5**

| Route | KML line vertices | Approx. KML length | KML route label |
|---|---:|---:|---|
| R1 | 573 | 30.44 km | R1 (Khokrapar No. 1 to Dockyard) |\n| R2 | 929 | 30.41 km | R2 (Power House Chowrangi to Korangi Crossing) |\n| R3 | 610 | 34.25 km | R3 (Power House Chowrangi to Nasir Jump) |\n| R4 | 956 | 24.06 km | R4 (Power House Chowrangi to Keamari) |\n| R8 | 603 | 17.17 km | R8 (Yousuf Goth to Tower) |\n| R9 | 626 | 41.97 km | R9 (Al Khidmat Hadeed to Tower) |\n| R10 | 959 | 28.46 km | R10 (Numaish to Ibrahim Hyderi) |\n| R11 | 779 | 18.95 km | R11 (Miran Nakka to Ziauddin Hospital) |\n| R12 | 596 | 34.15 km | R12 (Memon Goth to Lucky Star) |\n| R13 | 659 | 18.51 km | R13 (Hawksbay to Tower ) |\n| EV-01 | 693 | 37.83 km | EV1 (Malir Cantt to Dolmen Mall Clifton) |\n| EV-02 | 554 | 39.34 km | EV2 (Bahria Town to Malir Halt) |\n| EV-03 | 833 | 23.46 km | EV3 (Malir Cantt to Numaish) |\n| EV-04 | 948 | 43.34 km | EV4 (Bahria Town to Ayesha Manzil) |\n| EV-05 | 485 | 41.17 km | EV5 (DHA City to Sohrab Goth) |\n
## Coverage gaps and identity conflicts

### Routes absent from this KML
- **R5, R6, R7 and R14** are absent from the KML.
- The existing project route-conflict register records R14 as Active in SMTA material; its absence here is a source-coverage gap, not evidence that R14 does not exist.

### Routes in KML but missing from the existing official stop-sequence register
- **R9 and R10** have route geometry in this KML, but no R9/R10 rows were found in the project's Phase 5AF official stop-sequence file or Phase 5C published-stop file. Their stop names/order need separate official-source research.

### Existing identity conflicts retained
- **R1:** KML says “Khokrapar No. 1”; SMTA's sequence record uses “Khokharapar 04 / Kokharpar 04”. The existing alias review does not resolve the No. 1 vs 04 identity.
- **R2–R4:** KML route labels begin at Power House Chowrangi; current SMTA individual-page sequences describe North Karachi origins. The project's route-conflict register already records these origin conflicts. Do not rewrite either source.
- **R11:** KML says “Miran Nakka–Ziauddin Hospital”; SMTA detail sequence says “Mera Naka–Ziauddin Hospital”; the route index has another Miran Nakka variant. Existing conflict remains unresolved.
- **R12:** KML says “Memon Goth–Lucky Star”; SMTA detail says “Memon Goth–Sadar Lucky Star”; route index has a Naddi Kinara variant. Existing conflict remains unresolved.
- **EV-01:** KML uses “Malir Cantt–Dolmen Mall Clifton”; SMTA detail uses “CMH Malir Cantt–Dolmen Mall”. Retain as label variants pending operator stop identity evidence.
- **EV-03:** KML uses “Malir Cantt–Numaish”; SMTA detail descriptor says “Quaid-e-Azam Square Malir Cantt–Numaish via X-20”. Treat descriptor wording as a route identity reference, not a newly created stop.

## User waypoint checks

### EV-01
- All **18** Google Maps waypoints are within **{max_ev01:.1f} m** of the KML line.
- One waypoint-order inversion was found: the supplied waypoint order has **Tank Chowk before Model Colony**, but the KML line's nearest chainage places **Model Colony before Tank Chowk** ({ev01_inversions[0][2]:.2f} km vs {ev01_inversions[0][3]:.2f} km).
- This is recorded as a discrepancy only. The KML route and the user's waypoint order have not been changed.

### EV-02
- All **8** named waypoint coordinates (including the user-confirmed Domba Goth and user-supplied Karachi Toll Plaza coordinates) are within **{max_ev02:.1f} m** of the KML line.
- The user-provided Google Maps starting waypoint is at KML chainage **{ev02_start_chain:.2f} km**, while the KML line begins at chainage 0.00 km. The KML geometry therefore extends before the Google Maps route's first waypoint. This is a source difference to review, not a reason to trim the KML.
- The supplied waypoints occur in the same order along the KML line.

## Historical stop-coordinate crosswalk check

Compared **82 existing candidate coordinates** from `PHASE_5_STOP_NODE_CROSSWALK.csv` against the primary KML lines using nearest point-on-polyline distance:
- Within 250 m: **{counts.get('within_250m_candidate',0)}**
- 250 m to 1 km: **{counts.get('250m_to_1km_candidate',0)}**
- More than 1 km: **{counts.get('over_1km_candidate',0)}**

These are historical candidate coordinates, many previously marked `candidate_name_match` or `unmatched`; they are not verified physical boarding points. Large offsets may reflect stale or misassigned historical coordinates, route identity differences, or KML alignment differences. No automatic coordinate replacement was made.

Notable offsets to review:
- R1 PAF Base Faisal: about 7.20 km from KML line; Nursery about 3.29 km.
- R2 Indus Hospital: about 10.79 km; Shafiq Mor about 11.74 km.
- R3 Nursery: about 4.70 km; Board Office about 2.71 km.
- R8 Yousuf Goth historical candidate: about 26.48 km; Gulbai about 4.95 km.
- R13 Gulbai historical candidate: about 4.98 km.
- EV-03 Liaquat National Hospital historical candidate: about 4.07 km.
- EV-04 Ayesha Manzil historical candidate: about 9.35 km.

These offsets are **coordinate QA flags**, not proof that the KML is wrong or that the historical candidate is wrong. Verify against a current stop ID or physical boarding point before assigning coordinates.

## EV published-distance comparison

The existing SMTA EV reconciliation records published distances of 41, 44, 23, 58 and 48 km for EV-01 through EV-05. The KML line lengths are approximately:
- EV-01: KML 37.83 km vs SMTA published 41 km (difference -3.17 km).\n- EV-02: KML 39.34 km vs SMTA published 44 km (difference -4.66 km).\n- EV-03: KML 23.46 km vs SMTA published 23 km (difference +0.46 km).\n- EV-04: KML 43.34 km vs SMTA published 58 km (difference -14.66 km).\n- EV-05: KML 41.17 km vs SMTA published 48 km (difference -6.83 km).\n
The two distance figures may use different measurement conventions or route versions. Keep both source values; do not force the KML geometry to the published distance.

## Output files

- `route_inventory.csv`: all 15 route line summaries and endpoint coordinates.
- `historical_stop_candidate_to_kml_audit.csv`: 82 existing crosswalk coordinate candidates compared with their KML line.
- `user_waypoint_to_kml_audit.csv`: EV-01 and EV-02 user waypoint comparison.
- `route_geometries.geojson`: direct LineString conversion of the KML, preserving source coordinate order.
- Original KML is included unchanged.

## Decision

**Use the supplied KML as the primary route-geometry source.** Keep SMTA as the published stop-name/sequence source, retain user waypoint coordinates with their provenance, and use OSM only as supporting context. All conflicts and coordinate offsets remain review items. This audit does not authorize any database approval or route geometry mutation.
